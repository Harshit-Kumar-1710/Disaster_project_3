export interface NodeType {
  id: string;
  name: string;
  type?: 'normal' | 'safe' | 'warning' | 'danger';
  description?: string;
  x?: number;
  y?: number;
}

export interface EdgeType {
  id: string;
  source: string;
  target: string;
  weight: number;
  status?: 'open' | 'blocked';
}

export interface GraphType {
  nodes: { [id: string]: NodeType };
  edges: { [id: string]: EdgeType };
}