import { useState, useEffect, useCallback } from 'react';
import { GraphType } from '../types/graph';
import { mockGraph } from '../utils/mockData';

interface UseGraphReturn {
  graph: GraphType | null;
  loading: boolean;
  error: Error | null;
  refreshGraph: () => Promise<void>;
}

export const useGraph = (): UseGraphReturn => {
  const [graph, setGraph] = useState<GraphType | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  
  const fetchGraph = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      // In a real app, this would be an API call to get the current graph
      // For the demo, we'll use mock data with a slight delay to simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Use our mock graph data
      setGraph(mockGraph);
    } catch (e) {
      setError(e instanceof Error ? e : new Error('Failed to fetch graph data'));
      console.error('Error fetching graph:', e);
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Update graph with new data (e.g., after changes in emergency conditions)
  const refreshGraph = useCallback(async () => {
    setLoading(true);
    
    try {
      // Simulate API call to get updated graph
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For the demo, we'll just slightly modify the mock graph to simulate changes
      const updatedGraph = { ...mockGraph };
      
      // Randomly update some edge weights to simulate changing conditions
      Object.values(updatedGraph.edges).forEach(edge => {
        // 30% chance to update an edge
        if (Math.random() < 0.3) {
          // Add or subtract up to 20% of the weight
          const change = (Math.random() * 0.4 - 0.2) * edge.weight;
          edge.weight = Math.max(1, Math.round((edge.weight + change) * 10) / 10);
          
          // 10% chance to mark an edge as blocked
          if (Math.random() < 0.1) {
            edge.status = 'blocked';
          } else {
            edge.status = 'open';
          }
        }
      });
      
      setGraph(updatedGraph);
    } catch (e) {
      setError(e instanceof Error ? e : new Error('Failed to refresh graph data'));
      console.error('Error refreshing graph:', e);
    } finally {
      setLoading(false);
    }
  }, []);
  
  useEffect(() => {
    fetchGraph();
  }, [fetchGraph]);
  
  return { graph, loading, error, refreshGraph };
};